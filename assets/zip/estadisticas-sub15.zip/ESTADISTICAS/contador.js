var contadorPases = 0;
var contadorPasesRival = 0;
var contadorTirosArco = 0;
var contadorTirosErrados = 0;
var contadorCornerFavor = 0;
var contadorTirosLibres = 0;
var contadorTirosRival = 0;

var contPases = document.getElementById('cont-pases');
var contPasesRival = document.getElementById('cont-pases-rival');
var contTiros = document.getElementById('cont-tiros-arco');
var contErrados = document.getElementById('cont-tiros-errados');
var contCorner = document.getElementById('cont-corner-fav');
var contTirosLibres = document.getElementById('cont-libres-fav');
var contTirosRival = document.getElementById('cont-tiros-arco-rival');

var posesion = 0;
var posesionSel = document.getElementById('cont-posesion');


document.body.onkeyup = function(e) {
  if( e.keyCode == 65 ) {
    contadorPases++;
    contPases.innerText = ("Total de pases bien dado: "+contadorPases);
  }
  if( e.keyCode == 83 ) {
    contadorPasesRival++;
    contPasesRival.innerText = ("Total de pases bien dado del rival: "+contadorPasesRival);
  }
  if( e.keyCode == 84 ) {
    contadorTirosArco++;
    contTiros.innerText = ("Total de tiros al arco: "+contadorTirosArco);
  }
  if( e.keyCode == 70 ) {
    contadorTirosErrados++;
    contErrados.innerText = ("Total de tiros errados: "+contadorTirosErrados);
  }
  if( e.keyCode == 67 ) {
    contadorCornerFavor++;
    contCorner.innerText = ("Total de corners a favor: "+contadorCornerFavor);
  }
  if( e.keyCode == 76 ) {
    contadorTirosLibres++;
    contTirosLibres.innerText = ("Total de tiros libres a favor: "+contadorTirosLibres);
  }
  if( e.keyCode == 80 ) {
    contadorTirosRival++;
    contTirosRival.innerText = ("Total de tiros del rival: "+contadorTirosRival);
  }
  
  if( e.keyCode == 13 ) {
    posesion = (contadorPases/(contadorPases+contadorPasesRival)*100).toFixed(1);
    posesionSel.innerText = ("La posesión calculada es de:\n"+posesion+"%");
  }
}



